# Workshop für Schüler

1. Webserver starten. Z.B. ```php -S localhost:80``` oder ```python -m SimpleHTTPServer 80```
2. http://uh.diin.io/phaser-ws.zip herunter laden.
3. Im Webserver root entpacken.
4. Editor öffnen
5. Browser öffnen